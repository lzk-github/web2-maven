CREATE PROCEDURE fnin(IN inname VARCHAR(255))
  begin 
select * from t_account where `name`=inname;
end;
