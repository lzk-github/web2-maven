CREATE PROCEDURE fnout(OUT name1 VARCHAR(255), OUT name2 VARCHAR(255))
  begin select name into name1 from t_account where id=1;
select name into name2 from t_account where id=2;
end;
