CREATE PROCEDURE acc_2()
  begin 

update t_account set money=33.33 where id=1;
update t_account set enable=0 ;
select * from t_account;
end;
